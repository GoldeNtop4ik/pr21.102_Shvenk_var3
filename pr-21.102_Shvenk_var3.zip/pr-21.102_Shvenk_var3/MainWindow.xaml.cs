﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pr_21._102_Shvenk_var3
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Start_Click(object sender, RoutedEventArgs e)
        {
            
            try
            {
                int N = Convert.ToInt32(tBox_N.Text);
                int A = Convert.ToInt32(tBox_A.Text);
                int B = Convert.ToInt32(tBox_B.Text);
                int[] Array = new int[N];
                Random random = new Random();
                if (N > 0 && A > 0 && B > A)
                {
                    for (int i = 0; i < N; i++)
                    {
                        Array[i] = random.Next(A, B + 1);
                    }
                    string massiv = string.Join(" ", Array);
                    otvet.Text = massiv;
                    for (int i = 0; i < N - 1; i++)
                    {
                        for (int j = 0; j < N - 1; j++)
                        {
                            if (Array[j] % 2 != 0)
                            {
                                if (Array[j + 1] % 2 == 0)
                                {
                                    int tmp = Array[j];
                                    Array[j] = Array[j + 1];
                                    Array[j + 1] = tmp;
                                }
                            }
                        }
                    }
                    string sort = string.Join(" ", Array);
                    otvet_sort.Text = sort;
                }
                else
                {
                    otvet.Text = "Ошибка в начальных значениях";
                    otvet_sort.Text = "Ошибка в начальных значениях";
                }
            }
            catch (Exception ex)
            {
                otvet.Text = "Ошибка";
                otvet_sort.Text = "Ошибка";
            }
        }
    }
}
